package com.example.efinance.service;

import com.example.efinance.model.AutoLoan;


public interface AutoLoanService {
    void saveAutoLoan(AutoLoan autoLoan);
}
