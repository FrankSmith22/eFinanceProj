package com.example.efinance.service;

import com.example.efinance.model.StudentLoan;

public interface StudentLoanService {
    void saveLoan(StudentLoan studentLoan);
}
