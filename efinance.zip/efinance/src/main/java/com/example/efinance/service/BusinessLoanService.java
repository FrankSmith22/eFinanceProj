package com.example.efinance.service;

import com.example.efinance.model.BusinessLoan;

public interface BusinessLoanService {
    void saveLoan(BusinessLoan businessLoan);
}
