package com.example.efinance.service;

import com.example.efinance.model.PersonalLoan;
import com.example.efinance.repository.PersonalLoanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonalLoanServiceImpl implements PersonalLoanService{

    @Autowired
    private PersonalLoanRepository personalLoanRepository;

    @Override
    public void saveLoan(PersonalLoan personalLoan) {
        this.personalLoanRepository.save(personalLoan);
    }
}
