package com.example.efinance.service;

import com.example.efinance.model.PersonalLoan;

public interface PersonalLoanService {
    void saveLoan(PersonalLoan personalLoan);
}
