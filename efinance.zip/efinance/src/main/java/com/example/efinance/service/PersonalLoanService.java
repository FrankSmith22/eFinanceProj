package com.example.efinance.service;

import com.example.efinance.model.Loan;

public interface PersonalLoanService {
    void saveLoan(Loan loan);
}
