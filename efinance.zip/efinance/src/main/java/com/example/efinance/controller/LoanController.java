package com.example.efinance.controller;

import com.example.efinance.model.AutoLoan;
import com.example.efinance.model.BusinessLoan;
import com.example.efinance.model.PersonalLoan;
import com.example.efinance.model.StudentLoan;
import com.example.efinance.repository.AutoLoanRepository;
import com.example.efinance.repository.BusinessLoanRepository;
import com.example.efinance.repository.PersonalLoanRepository;
import com.example.efinance.repository.StudentLoanRepository;
import com.example.efinance.service.AutoLoanService;
import com.example.efinance.service.BusinessLoanService;
import com.example.efinance.service.PersonalLoanService;
import com.example.efinance.service.StudentLoanService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class LoanController {
    private static final Logger log = LoggerFactory.getLogger(LoanController.class);

    @Autowired
    private AutoLoanRepository autoLoanRepository;
    @Autowired
    private BusinessLoanRepository businessLoanRepository;
    @Autowired
    private PersonalLoanRepository personalLoanRepository;
    @Autowired
    private StudentLoanRepository studentLoanRepository;


    @Autowired
    private PersonalLoanService personalLoanService;
    @Autowired
    private BusinessLoanService businessLoanService;
    @Autowired
    private StudentLoanService studentLoanService;
    @Autowired
    private AutoLoanService autoLoanService;

    @GetMapping("/loanApplication")
    public String showApplication(Model model){
        return "loan_select";
    }

    //Personal Loan

    @GetMapping("/personalLoan")
    public String showPersonalLoan(Model model){
        model.addAttribute("personalLoan", new PersonalLoan());
        return "personal_loan_application";
    }

    @PostMapping("/personalLoan")
    public String showPersonalLoan(@ModelAttribute("personalLoan") PersonalLoan personalLoan, Model model){
        personalLoanService.saveLoan(personalLoan);
        return "thank_you";
    }

    //Auto Loan

    @GetMapping("/autoLoan")
    public String showAutoLoan(Model model){
        model.addAttribute("autoLoan", new AutoLoan());
        return "auto_loan_application";
    }

    @PostMapping("/autoLoan")
    public String showAutoLoan(@ModelAttribute("autoLoan") AutoLoan autoLoan, Model model){
        autoLoanService.saveLoan(autoLoan);
        return "thank_you";
    }

    //Business Loan

    @GetMapping("/businessLoan")
    public String showBusinessLoan(Model model){
        model.addAttribute("businessLoan", new BusinessLoan());
        return "business_loan_application";
    }

    @PostMapping("/businessLoan")
    public String showBusinessLoan(@ModelAttribute("businessLoan") BusinessLoan businessLoan, Model model){
        businessLoanService.saveLoan(businessLoan);
        return "thank_you";
    }

    //Student Loan

    @GetMapping("/studentLoan")
    public String showStudentLoan(Model model){
        model.addAttribute("studentLoan", new StudentLoan());
        return "student_loan_application";
    }

    @PostMapping("/studentLoan")
    public String showStudentLoan(@ModelAttribute("studentLoan") StudentLoan studentLoan, Model model){
        studentLoanService.saveLoan(studentLoan);

        return "thank_you";
    }
}
