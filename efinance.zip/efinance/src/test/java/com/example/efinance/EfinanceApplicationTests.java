package com.example.efinance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EfinanceApplicationTests {

    @Test
    void contextLoads() {
    }

}
